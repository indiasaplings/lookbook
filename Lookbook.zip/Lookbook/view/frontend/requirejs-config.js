var config = {
	map: {
        '*': {
            magiccartLookbook: 'Magiccart_Lookbook/js/lookbook'
        }
    }
};
